应用多态性和“do it myself”模式来将谣言对象和新闻对象进行抽象概化

![image-20200607164821474](https://picbed-1301760901.cos.ap-guangzhou.myqcloud.com/image-20200607164821474.png)